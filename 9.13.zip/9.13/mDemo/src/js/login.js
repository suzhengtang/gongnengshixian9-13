$(document).ready(function () {
    $('.login-content a').click(function () {
        $.ajax({
            type: "post",
            url: "http://192.168.31.240:3000/api/user/login",
            data: {username:$("#username").val(), userword:$("#userword").val()},
            dataType: "json",
            success: function(data){
                console.log(data);
            },
            error:function (err) {
                console.log(err);
            }
        });


    })
});